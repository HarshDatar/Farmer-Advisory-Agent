from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json
import os
import pickle
import urllib.error
import urllib.request
import warnings

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

warnings.filterwarnings("ignore")


PROJECT_DIR = Path(__file__).resolve().parent
MODEL_DIR = PROJECT_DIR / "models"
KB_DIR = PROJECT_DIR / "knowledge_base"


# ── Default inputs for models when farmer has not given specifics ──
DEFAULT_CROP_INPUT = {
    "N": 50,
    "P": 40,
    "K": 20,
    "temperature": 28,
    "humidity": 65,
    "ph": 7.5,
    "rainfall": 150,
}

DEFAULT_SOIL_INPUT = {
    "soil_type": "Clay",
    "ph": 6.5,
    "ec": 1.2,
    "organic_carbon": 1.0,
    "nitrogen": 200,
    "phosphorus": 40,
    "potassium": 300,
    "moisture": 25,
    "temperature": 24,
}

MAHARASHTRA_CROP_NAMES = {
    "blackgram",
    "chickpea",
    "cotton",
    "grapes",
    "maize",
    "mango",
    "mothbeans",
    "mungbean",
    "orange",
    "pigeonpeas",
    "pomegranate",
    "rice",
}

# Keywords to decide which tool (model) to use for a question
TOOL_KEYWORDS = {
    "recommend_crops": [
        "crop", "grow", "plant", "cultivate", "kharif", "rabi",
        "season", "sow", "seed", "which crop", "best crop",
        "what to grow", "farming",
    ],
    "classify_soil": [
        "soil", "quality", "fertile", "ph", "nitrogen", "organic",
        "land", "ground", "mitti", "soil health",
    ],
    "price_forecast": [
        "price", "mandi", "sell", "market", "cost", "rate",
        "onion", "potato", "money", "selling", "buy",
    ],
    "weather_lookup": [
        "weather", "rain", "temperature", "climate", "rainfall",
        "humid", "wind", "cold", "hot", "monsoon", "barish",
    ],
}


class AgentSetupError(RuntimeError):
    """Raised when the trained local models cannot be loaded."""


# ── File loaders ──────────────────────────────────────────────

def _load_pickle(filename: str) -> Any:
    path = MODEL_DIR / filename
    if not path.exists():
        raise AgentSetupError(f"Missing model file: {path}")
    with path.open("rb") as handle:
        return pickle.load(handle)


def _display_crop_name(name: Any) -> str:
    return str(name).replace("_", " ").strip().title()


# ── RAG: Knowledge Base Retriever ─────────────────────────────

class KnowledgeBase:
    """Simple TF-IDF based retrieval over text files in knowledge_base/."""

    def __init__(self, kb_dir: Path | str = KB_DIR):
        self.kb_dir = Path(kb_dir)
        self.chunks: list[str] = []
        self.sources: list[str] = []
        self.vectorizer: TfidfVectorizer | None = None
        self.tfidf_matrix = None
        self._load()

    def _load(self) -> None:
        """Read all .txt files, split into chunks by paragraph."""
        if not self.kb_dir.exists():
            return

        for filepath in sorted(self.kb_dir.glob("*.txt")):
            text = filepath.read_text(encoding="utf-8", errors="ignore")
            # Split by double newline (paragraphs) for chunking
            paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
            # Also split very long paragraphs by single newline
            for para in paragraphs:
                # Each sentence/line becomes its own chunk for better matching
                lines = [line.strip() for line in para.split("\n") if line.strip()]
                # Group 2-3 lines together for context
                for i in range(0, len(lines), 2):
                    chunk = " ".join(lines[i : i + 3])
                    if len(chunk) > 30:  # Skip tiny chunks
                        self.chunks.append(chunk)
                        self.sources.append(filepath.stem)

        if self.chunks:
            self.vectorizer = TfidfVectorizer(
                stop_words="english",
                max_features=5000,
                ngram_range=(1, 2),
            )
            self.tfidf_matrix = self.vectorizer.fit_transform(self.chunks)

    def search(self, query: str, top_k: int = 4) -> list[dict[str, str]]:
        """Find the most relevant chunks for a query."""
        if not self.chunks or self.vectorizer is None:
            return []

        query_vec = self.vectorizer.transform([query.lower()])
        scores = cosine_similarity(query_vec, self.tfidf_matrix)[0]
        top_indices = scores.argsort()[-top_k:][::-1]

        results = []
        for idx in top_indices:
            if scores[idx] > 0.05:  # Only return if somewhat relevant
                results.append({
                    "text": self.chunks[idx],
                    "source": self.sources[idx],
                    "score": float(scores[idx]),
                })
        return results


# ── LLM loader ────────────────────────────────────────────────

def _find_local_gguf() -> tuple[str, str] | tuple[None, None]:
    explicit_file = os.getenv("KISAN_SAATHI_GGUF_FILE")
    explicit_dir = os.getenv("KISAN_SAATHI_GGUF_DIR")
    if explicit_file and explicit_dir and (Path(explicit_dir) / explicit_file).exists():
        return explicit_file, explicit_dir

    candidate_dirs = [
        MODEL_DIR,
        Path.home() / "AppData" / "Local" / "nomic.ai" / "GPT4All",
        Path.home() / ".cache" / "gpt4all",
    ]
    preferred_tokens = ("llama-3.2-3b-instruct", "phi-3-mini", "instruct")

    found: list[Path] = []
    for directory in candidate_dirs:
        try:
            if directory.exists():
                found.extend(directory.glob("*.gguf"))
        except OSError:
            continue

    if not found:
        return None, None

    found.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    for token in preferred_tokens:
        for path in found:
            if token in path.name.lower():
                return path.name, str(path.parent)
    first = found[0]
    return first.name, str(first.parent)


def load_llm() -> Any | None:
    model_file, model_dir = _find_local_gguf()
    if not model_file or not model_dir:
        return None

    try:
        from gpt4all import GPT4All

        return GPT4All(
            model_name=model_file,
            model_path=model_dir,
            allow_download=False,
            n_threads=4,
            n_ctx=1024,
            verbose=False,
        )
    except Exception:
        return None


def _is_gemini_key(api_key: str) -> bool:
    """Gemini keys start with AIza."""
    return api_key.strip().startswith("AIza")


def call_gemini_llm(
    prompt: str,
    api_key: str,
    *,
    model: str = "gemini-1.5-flash",
    max_tokens: int = 180,
    temperature: float = 0.55,
) -> str:
    """Call Google Gemini API directly (no extra packages needed)."""
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{model}:generateContent?key={api_key}"
    )
    payload = json.dumps(
        {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        body = json.loads(response.read().decode("utf-8"))
    return str(body["candidates"][0]["content"]["parts"][0]["text"]).strip()


def call_api_llm(
    prompt: str,
    api_key: str,
    *,
    base_url: str = "https://api.openai.com/v1",
    model: str = "gpt-4o-mini",
    max_tokens: int = 180,
    temperature: float = 0.55,
) -> str:
    """Call Gemini (if key starts with AIza) or any OpenAI-compatible API."""
    if _is_gemini_key(api_key):
        # Use gemini-1.5-flash by default; if user set a custom model use it
        gemini_model = model if model.startswith("gemini") else "gemini-1.5-flash"
        return call_gemini_llm(
            prompt,
            api_key,
            model=gemini_model,
            max_tokens=max_tokens,
            temperature=temperature,
        )

    # OpenAI-compatible path (OpenAI, Groq, etc.)
    url = f"{base_url.rstrip('/')}/chat/completions"
    payload = json.dumps(
        {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        body = json.loads(response.read().decode("utf-8"))
    return str(body["choices"][0]["message"]["content"]).strip()


def default_api_key() -> str | None:
    key = os.getenv("KISAN_SAATHI_API_KEY", "").strip()
    return key or None


def default_api_base() -> str:
    return os.getenv("KISAN_SAATHI_API_BASE", "https://api.openai.com/v1").strip()


def default_api_model() -> str:
    return os.getenv("KISAN_SAATHI_API_MODEL", "gemini-1.5-flash").strip()


LLM_SYSTEM_PROMPT = """You are Kisan Saathi, a practical farming advisor for smallholder farmers in Maharashtra.
Write like a knowledgeable neighbour. Use simple English that an uneducated farmer can understand.
Do not mention models, tools, confidence scores or software.
Give direct practical advice. Keep the answer under 100 words."""


def build_llm_prompt(agent: "FarmerAgent", query: str, context: str) -> str:
    memory = agent.recent_memory_text()
    parts = [LLM_SYSTEM_PROMPT, ""]
    if memory:
        parts.extend([memory, ""])
    parts.extend(
        [
            "Farm data and knowledge:",
            context,
            "",
            f"Farmer's question: {query}",
            "Kisan Saathi:",
        ]
    )
    return "\n".join(parts)


# ── The Agent ─────────────────────────────────────────────────

@dataclass
class FarmerAgent:
    crop_model: Any
    crop_label_encoder: Any
    soil_model: Any
    soil_type_encoder: Any
    soil_quality_encoder: Any
    price_data: dict[str, dict[str, Any]]
    weather_data: dict[str, Any]
    knowledge_base: KnowledgeBase
    llm: Any | None = None
    _llm_loading: bool = False
    api_key: str | None = field(default_factory=default_api_key)
    api_base: str = field(default_factory=default_api_base)
    api_model: str = field(default_factory=default_api_model)
    llm_mode: str = "auto"  # local | api | auto
    last_llm_source: str = "fallback"
    memory_limit: int = 6
    chat_memory: list[dict[str, str]] = field(default_factory=list)

    def configure_llm(
        self,
        *,
        mode: str | None = None,
        api_key: str | None = None,
        api_base: str | None = None,
        api_model: str | None = None,
    ) -> None:
        if mode is not None:
            self.llm_mode = mode
        if api_key is not None:
            cleaned = api_key.strip()
            self.api_key = cleaned or None
        if api_base is not None and api_base.strip():
            self.api_base = api_base.strip()
        if api_model is not None and api_model.strip():
            self.api_model = api_model.strip()

    def llm_status(self) -> dict[str, str]:
        def _api_label() -> str:
            if self.api_key and _is_gemini_key(self.api_key):
                return "Gemini ready"
            return "Cloud API ready"

        if self.llm_mode == "api":
            if self.api_key:
                return {"label": _api_label(), "detail": self.api_model}
            return {"label": "API key needed", "detail": "Add key in sidebar"}

        if self.llm_mode == "local":
            if self.llm is not None:
                return {"label": "Local AI ready", "detail": "On this device"}
            if self._llm_loading:
                return {"label": "Loading local AI…", "detail": "Please wait"}
            return {"label": "Local model not found", "detail": "Uses RAG fallback"}

        # auto
        if self.llm is not None:
            return {"label": "Local AI ready", "detail": "Auto mode"}
        if self._llm_loading:
            return {"label": "Loading local AI…", "detail": "Auto mode"}
        if self.api_key:
            return {"label": _api_label(), "detail": "Auto — local unavailable"}
        return {"label": "RAG + farm models", "detail": "No LLM loaded"}

    def _generate_local(self, prompt: str) -> str | None:
        if self.llm is None:
            return None
        try:
            with self.llm.chat_session():
                return self.llm.generate(prompt=prompt, max_tokens=150, temp=0.55).strip()
        except Exception:
            return None

    def _generate_api(self, prompt: str) -> str | None:
        if not self.api_key:
            return None
        try:
            return call_api_llm(
                prompt,
                self.api_key,
                base_url=self.api_base,
                model=self.api_model,
            )
        except (urllib.error.URLError, urllib.error.HTTPError, KeyError, ValueError, TimeoutError):
            return None

    def _generate_with_llm(self, query: str, context: str) -> str | None:
        prompt = build_llm_prompt(self, query, context)

        if self.llm_mode == "api":
            response = self._generate_api(prompt)
            if response:
                self.last_llm_source = "api"
            return response

        if self.llm_mode == "local":
            response = self._generate_local(prompt)
            if response:
                self.last_llm_source = "local"
            return response

        response = self._generate_local(prompt)
        if response:
            self.last_llm_source = "local"
            return response

        response = self._generate_api(prompt)
        if response:
            self.last_llm_source = "api"
            return response

        return None

    def start_llm_background(self) -> None:
        """Load the LLM in a background thread so it does not block the UI."""
        import threading

        if self.llm is not None or self._llm_loading:
            return  # already loaded or already loading

        def _load():
            self._llm_loading = True
            try:
                self.llm = load_llm()
            except Exception:
                self.llm = None
            finally:
                self._llm_loading = False

        thread = threading.Thread(target=_load, daemon=True)
        thread.start()

    # ── Memory ────────────────────────────────────────────

    def remember(self, role: str, message: str) -> None:
        self.chat_memory.append({"role": role, "message": message})
        if len(self.chat_memory) > self.memory_limit:
            self.chat_memory = self.chat_memory[-self.memory_limit :]

    def recent_memory_text(self) -> str:
        if not self.chat_memory:
            return ""
        lines = ["Recent conversation:"]
        for item in self.chat_memory[-4:]:
            lines.append(f"{item['role']}: {item['message'][:180]}")
        return "\n".join(lines)

    # ── ML Model tools ────────────────────────────────────

    def recommend_crops(self, values: dict[str, float] | None = None) -> list[dict[str, Any]]:
        values = {**DEFAULT_CROP_INPUT, **(values or {})}
        sample = pd.DataFrame(
            [[values[col] for col in ["N", "P", "K", "temperature", "humidity", "ph", "rainfall"]]],
            columns=["N", "P", "K", "temperature", "humidity", "ph", "rainfall"],
        )
        probs = self.crop_model.predict_proba(sample)[0]
        regional_idx = [
            idx
            for idx, name in enumerate(self.crop_label_encoder.classes_)
            if str(name).lower() in MAHARASHTRA_CROP_NAMES
        ]
        ranked_idx = sorted(regional_idx or range(len(probs)), key=lambda idx: probs[idx], reverse=True)
        top_idx = ranked_idx[:3]

        return [
            {
                "name": _display_crop_name(self.crop_label_encoder.classes_[idx]),
                "confidence": float(probs[idx]),
            }
            for idx in top_idx
        ]

    def classify_soil(self, values: dict[str, Any] | None = None) -> dict[str, Any]:
        values = {**DEFAULT_SOIL_INPUT, **(values or {})}
        try:
            soil_encoded = self.soil_type_encoder.transform([values["soil_type"]])[0]
        except Exception:
            soil_encoded = self.soil_type_encoder.transform([self.soil_type_encoder.classes_[0]])[0]

        sample = pd.DataFrame(
            [
                [
                    soil_encoded,
                    values["ph"],
                    values["ec"],
                    values["organic_carbon"],
                    values["nitrogen"],
                    values["phosphorus"],
                    values["potassium"],
                    values["moisture"],
                    values["temperature"],
                ]
            ],
            columns=[
                "Soil_Type_encoded", "pH", "EC", "Organic_Carbon",
                "Nitrogen", "Phosphorus", "Potassium", "Moisture", "Temperature",
            ],
        )
        pred = self.soil_model.predict(sample)[0]
        probabilities = self.soil_model.predict_proba(sample)[0]
        quality = str(self.soil_quality_encoder.inverse_transform([pred])[0]).title()
        return {
            "quality": quality,
            "confidence": float(max(probabilities)),
            "soil_type": values["soil_type"],
            "ph": values["ph"],
        }

    def price_forecasts(self, crop_names: list[str] | None = None) -> list[dict[str, Any]]:
        crop_names = crop_names or ["Onion", "Potato"]
        rows = []
        for crop in crop_names:
            data = self.price_data.get(crop)
            if not data:
                continue
            rows.append(
                {
                    "crop": crop,
                    "current": float(data["last_price"]),
                    "forecast": float(data["next_month_forecast"]),
                    "trend": str(data.get("trend", "flat")).lower(),
                }
            )
        return rows

    def weather_cards(self, city: str = "Pune", months: tuple[int, ...] = (6, 7, 8, 9)) -> list[dict[str, Any]]:
        month_names = {
            1: "January", 2: "February", 3: "March", 4: "April",
            5: "May", 6: "June", 7: "July", 8: "August",
            9: "September", 10: "October", 11: "November", 12: "December",
        }
        symbols = {6: "&#9729;", 7: "&#9730;", 8: "&#9730;", 9: "&#9729;"}
        cards = []
        for month in months:
            key = (city, month)
            temp_data = self.weather_data.get("temperature", {}).get(key)
            if temp_data:
                cards.append(
                    {
                        "month": month_names[month],
                        "temp": float(temp_data["mean"]),
                        "symbol": symbols.get(month, "&#9728;"),
                    }
                )
        return cards

    # ── Tool selection ────────────────────────────────────

    def select_tools(self, query: str) -> list[str]:
        q = query.lower()
        selected = [
            tool for tool, keywords in TOOL_KEYWORDS.items() if any(keyword in q for keyword in keywords)
        ]
        return selected or ["recommend_crops"]

    # ── RAG retrieval ─────────────────────────────────────

    @staticmethod
    def _clean_kb_text(text: str, max_sentences: int = 3) -> str:
        """Remove section headings and limit to a few sentences."""
        # Word-level heading stripping: remove leading ALL-CAPS words
        # e.g. "COTTON PESTS Bollworm..." -> "Bollworm..."
        # e.g. "WHEN TO SELL Check mandi..." -> "Check mandi..."
        # e.g. "GOVERNMENT SCHEMES PM-KISAN scheme..." -> "PM-KISAN scheme..."
        words = text.strip().split()
        start = 0
        for i, word in enumerate(words):
            clean_word = word.strip("(),:;")
            # A heading word is pure ALL-CAPS letters (no hyphens).
            # Hyphenated words like PM-KISAN are content, not headings.
            if (clean_word
                    and clean_word.isalpha()
                    and clean_word == clean_word.upper()
                    and len(clean_word) >= 2):
                start = i + 1
            else:
                break
        # Only strip if we found 2+ consecutive ALL-CAPS words
        if start >= 2:
            text = " ".join(words[start:])
        else:
            text = text.strip()
        # Split into sentences
        sentences = [s.strip() for s in text.split(". ") if s.strip()]
        # Filter out any sentence that is still mostly uppercase (headings)
        cleaned = []
        for s in sentences:
            upper_chars = sum(1 for c in s if c.isupper())
            total_chars = sum(1 for c in s if c.isalpha())
            if total_chars > 0 and (upper_chars / total_chars) < 0.5:
                cleaned.append(s)
        result = ". ".join(cleaned[:max_sentences])
        if result and not result.endswith("."):
            result += "."
        return result

    def retrieve_knowledge(self, query: str) -> str:
        """Search knowledge base and return relevant text."""
        results = self.knowledge_base.search(query, top_k=4)
        if not results:
            return ""
        lines = ["Farming knowledge:"]
        for r in results:
            lines.append(f"- {r['text']}")
        return "\n".join(lines)

    def retrieve_knowledge_clean(self, query: str, max_sentences: int = 3) -> str:
        """Search KB and return clean, readable text for direct use in answers."""
        results = self.knowledge_base.search(query, top_k=2)
        if not results or results[0]["score"] < 0.10:
            return ""
        return self._clean_kb_text(results[0]["text"], max_sentences)

    # ── Build context from tools + RAG ────────────────────

    def tool_context(self, query: str) -> str:
        selected = self.select_tools(query)
        parts: list[str] = []

        if "recommend_crops" in selected:
            crops = self.recommend_crops()
            parts.append(
                "Best crops for this land: "
                + ", ".join(f"{crop['name']}" for crop in crops)
                + "."
            )

        if "classify_soil" in selected:
            soil = self.classify_soil()
            parts.append(
                f"Soil health: {soil['quality']} on {soil['soil_type']} soil with pH {soil['ph']}."
            )

        if "price_forecast" in selected:
            prices = self.price_forecasts()
            parts.extend(
                f"{row['crop']} mandi price is now Rs. {row['current']:.0f}; "
                f"expected next month Rs. {row['forecast']:.0f}, trend {row['trend']}."
                for row in prices
            )

        if "weather_lookup" in selected:
            weather = self.weather_cards()
            if weather:
                parts.append(
                    "Pune monsoon temperatures: "
                    + ", ".join(f"{row['month']} {row['temp']:.0f} C" for row in weather)
                    + "."
                )

        # RAG: Add knowledge base context
        kb_context = self.retrieve_knowledge(query)
        if kb_context:
            parts.append(kb_context)

        return "\n".join(parts)

    # ── Answer generation ─────────────────────────────────

    def fallback_answer(self, query: str, context: str) -> str:
        """Generate answer without LLM using model data + knowledge base."""
        selected = self.select_tools(query)

        # Get clean KB text for enriching the answer
        kb_text = self.retrieve_knowledge_clean(query, max_sentences=2)

        if "price_forecast" in selected:
            rows = self.price_forecasts()
            if rows:
                bits = [
                    f"{row['crop']} is around Rs. {row['current']:.0f} now and may reach "
                    f"Rs. {row['forecast']:.0f} next month"
                    for row in rows
                ]
                answer = "For the mandi, " + "; ".join(bits) + "."
                if kb_text:
                    answer += f" {kb_text}"
                else:
                    answer += " Watch local arrivals before deciding the selling day."
                return answer

        if "classify_soil" in selected:
            soil = self.classify_soil()
            answer = (
                f"Your soil health looks {soil['quality'].lower()} for {soil['soil_type'].lower()} "
                f"soil at pH {soil['ph']}."
            )
            if kb_text:
                answer += f" {kb_text}"
            else:
                answer += " Keep organic matter steady and avoid heavy watering if the field is already moist."
            return answer

        if "weather_lookup" in selected:
            weather = self.weather_cards()
            if weather:
                summary = ", ".join(f"{row['month']} near {row['temp']:.0f} C" for row in weather)
                answer = f"For Pune, the coming monsoon months look warm: {summary}."
                if kb_text:
                    answer += f" {kb_text}"
                else:
                    answer += " Plan sowing around the first reliable rains."
                return answer

        # If KB has a strong match for any other query, use it
        if kb_text:
            crops = self.recommend_crops()
            crop_names = [c["name"] for c in crops]
            return f"For your land, {crop_names[0]} looks like a strong choice. {kb_text}"

        # Default: crop recommendation
        crops = self.recommend_crops()
        names = [crop["name"] for crop in crops]
        return (
            f"For your land, {names[0]} looks the strongest choice right now. "
            f"{names[1]} and {names[2]} are also suitable if seed, water and "
            f"market access are better for you."
        )

    def answer(self, query: str) -> str:
        """Main entry point: farmer asks a question, agent answers."""
        query = query.strip()
        if not query:
            return "Tell me what you want to decide today: crop, soil, weather or mandi price."

        self.remember("Farmer", query)
        context = self.tool_context(query)

        response = self._generate_with_llm(query, context)
        if response is None:
            self.last_llm_source = "fallback"
            response = self.fallback_answer(query, context)

        # Clean up any model artifacts from response
        for marker in ["<|assistant|>", "<|end|>", "Farmer's question:", "Kisan Saathi:"]:
            if marker in response:
                response = response.split(marker)[0].strip()

        self.remember("Kisan Saathi", response)
        return response

    def get_tools_used(self, query: str) -> list[str]:
        """Return which tools/models were used for a query (for transparency)."""
        tools = self.select_tools(query)
        kb_results = self.knowledge_base.search(query, top_k=1)
        tool_names = []
        for t in tools:
            if t == "recommend_crops":
                tool_names.append("Crop Model")
            elif t == "classify_soil":
                tool_names.append("Soil Model")
            elif t == "price_forecast":
                tool_names.append("Price Model")
            elif t == "weather_lookup":
                tool_names.append("Weather Data")
        if kb_results and kb_results[0]["score"] > 0.05:
            tool_names.append(f"Knowledge Base ({kb_results[0]['source']})")
        return tool_names


# ── Factory ───────────────────────────────────────────────────

def load_farmer_agent(include_llm: bool = True) -> FarmerAgent:
    kb = KnowledgeBase(KB_DIR)
    agent = FarmerAgent(
        crop_model=_load_pickle("crop_recommender.pkl"),
        crop_label_encoder=_load_pickle("crop_label_encoder.pkl"),
        soil_model=_load_pickle("soil_classifier.pkl"),
        soil_type_encoder=_load_pickle("soil_type_encoder.pkl"),
        soil_quality_encoder=_load_pickle("soil_quality_encoder.pkl"),
        price_data=_load_pickle("price_forecaster.pkl"),
        weather_data=_load_pickle("weather_patterns.pkl"),
        knowledge_base=kb,
        llm=load_llm() if include_llm else None,
    )
    return agent


if __name__ == "__main__":
    farmer_agent = load_farmer_agent(include_llm=True)
    print("Kisan Saathi is ready. Type 'quit' to exit.")
    print(f"Knowledge base loaded: {len(farmer_agent.knowledge_base.chunks)} chunks")
    while True:
        question = input("You: ").strip()
        if question.lower() in {"quit", "exit", "bye"}:
            print("Kisan Saathi: Goodbye. May your season go well.")
            break
        tools = farmer_agent.get_tools_used(question)
        print(f"  [Tools: {', '.join(tools)}]")
        print(f"Kisan Saathi: {farmer_agent.answer(question)}")

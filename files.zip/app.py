from __future__ import annotations

import os
import warnings

import streamlit as st

from FarmerAgent import AgentSetupError, KB_DIR, load_farmer_agent

warnings.filterwarnings("ignore")

st.set_page_config(
    page_title="Kisan Saathi",
    page_icon="🌾",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
<style>
#MainMenu, header, footer,
[data-testid="stToolbar"],
[data-testid="stDecoration"],
[data-testid="stStatusWidget"],
[data-testid="stHeader"] {
    display: none !important;
}

:root {
    --green: #2e7d32;
    --green-dark: #1b5e20;
    --green-soft: #e8f5e9;
    --border: #dce8dc;
    --text: #1a1a1a;
    --muted: #666;
}

html, body, [class*="css"] {
    font-family: "Segoe UI", system-ui, sans-serif !important;
}

.block-container {
    padding-top: 1rem !important;
    max-width: 960px;
}

[data-testid="stSidebar"] {
    background: #ffffff !important;
    border-right: 2px solid var(--green-soft);
}
[data-testid="stSidebar"] .block-container {
    padding-top: 1.5rem !important;
}

.brand {
    color: var(--green-dark);
    font-size: 1.4rem;
    font-weight: 700;
    margin: 0;
}
.brand-sub {
    color: var(--muted);
    font-size: 0.85rem;
    margin: 0.2rem 0 1rem;
}

.panel {
    background: #fff;
    border: 1px solid var(--border);
    border-left: 4px solid var(--green);
    border-radius: 8px;
    padding: 0.75rem 0.9rem;
    margin-bottom: 0.75rem;
}
.panel-title {
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: var(--green-dark);
    margin: 0 0 0.45rem;
}
.panel-row {
    display: flex;
    justify-content: space-between;
    font-size: 0.88rem;
    padding: 0.2rem 0;
    color: var(--text);
}
.panel-row span:last-child {
    font-weight: 600;
    color: var(--green-dark);
}

.main-head {
    background: #fff;
    border: 1px solid var(--border);
    border-bottom: 3px solid var(--green);
    border-radius: 10px;
    padding: 1rem 1.2rem;
    margin-bottom: 1rem;
}
.main-head h1 {
    margin: 0;
    font-size: 1.35rem;
    color: var(--green-dark);
}
.main-head p {
    margin: 0.3rem 0 0;
    color: var(--muted);
    font-size: 0.95rem;
}

[data-testid="stChatMessage"]:has([data-testid="chatAvatarIcon-assistant"]) [data-testid="stChatMessageContent"] {
    background: var(--green-soft) !important;
    border: 1px solid var(--border) !important;
}
[data-testid="stChatMessage"]:has([data-testid="chatAvatarIcon-user"]) [data-testid="stChatMessageContent"] {
    background: #fff !important;
    border: 1px solid var(--border) !important;
}

.tag {
    display: inline-block;
    font-size: 0.72rem;
    background: var(--green-soft);
    color: var(--green-dark);
    border-radius: 4px;
    padding: 0.12rem 0.45rem;
    margin: 0.15rem 0.25rem 0 0;
}

div[data-testid="column"] .stButton > button {
    border-color: var(--green) !important;
    color: var(--green-dark) !important;
}
div[data-testid="column"] .stButton > button:hover {
    background: var(--green-soft) !important;
}
</style>
""",
    unsafe_allow_html=True,
)


@st.cache_resource(show_spinner=False)
def get_agent():
    agent = load_farmer_agent(include_llm=False)
    agent.start_llm_background()
    return agent


WELCOME_MSG = {
    "role": "assistant",
    "text": (
        "Namaskar! I am Kisan Saathi.\n\n"
        "Ask me about crops, soil, mandi prices, weather, pests, or schemes. "
        "I use farming guides on this computer and can also use local AI or a cloud API."
    ),
}


def kb_doc_count(agent) -> int:
    return len(set(agent.knowledge_base.sources)) if agent.knowledge_base.sources else 0


def sync_agent_settings(agent) -> None:
    agent.configure_llm(
        mode=st.session_state.llm_mode,
        api_key=st.session_state.api_key,
        api_base=st.session_state.api_base,
        api_model=st.session_state.api_model,
    )


def engine_label(agent) -> str:
    source = agent.last_llm_source
    if source == "local":
        return "Local AI"
    if source == "api":
        return "Cloud API"
    if source == "fallback":
        return "RAG fallback"
    return agent.llm_status()["label"]


try:
    agent = get_agent()
except (AgentSetupError, ModuleNotFoundError, ImportError) as exc:
    st.error(f"Could not start Kisan Saathi.\n\n{exc}")
    st.stop()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = [WELCOME_MSG]
if "llm_mode" not in st.session_state:
    st.session_state.llm_mode = "auto"
if "api_key" not in st.session_state:
    st.session_state.api_key = os.getenv("KISAN_SAATHI_API_KEY", "")
if "api_base" not in st.session_state:
    st.session_state.api_base = os.getenv(
        "KISAN_SAATHI_API_BASE", "https://api.openai.com/v1"
    )
if "api_model" not in st.session_state:
    st.session_state.api_model = os.getenv("KISAN_SAATHI_API_MODEL", "gemini-1.5-flash")

sync_agent_settings(agent)
status = agent.llm_status()


# ── Sidebar dashboard ─────────────────────────────────────────
with st.sidebar:
    st.markdown('<p class="brand">🌾 Kisan Saathi</p>', unsafe_allow_html=True)
    st.markdown('<p class="brand-sub">Farming assistant · Maharashtra</p>', unsafe_allow_html=True)

    st.markdown(
        f"""
        <div class="panel">
            <p class="panel-title">Status</p>
            <div class="panel-row"><span>Engine</span><span>{status["label"]}</span></div>
            <div class="panel-row"><span>Detail</span><span>{status["detail"]}</span></div>
            <div class="panel-row"><span>Knowledge</span><span>{kb_doc_count(agent)} guides</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("**AI mode**")
    st.session_state.llm_mode = st.radio(
        "AI mode",
        options=["auto", "local", "api"],
        format_func=lambda x: {
            "auto": "Auto (local first, then API)",
            "local": "Local only",
            "api": "Cloud API only",
        }[x],
        label_visibility="collapsed",
    )

    with st.expander("Cloud API settings", expanded=st.session_state.llm_mode == "api"):
        st.session_state.api_key = st.text_input(
            "API key",
            value=st.session_state.api_key,
            type="password",
            placeholder="AIza… (Gemini) or sk-… (OpenAI/Groq)",
            help="Paste your Gemini key (starts with AIza) or any OpenAI-compatible key.",
        )
        st.caption(
            "🟢 **Gemini keys** (AIza…) auto-detected — no extra setup needed.\n\n"
            "For OpenAI/Groq, also set the base URL and model name below."
        )
        st.session_state.api_base = st.text_input(
            "API base URL (OpenAI/Groq only)",
            value=st.session_state.api_base,
            placeholder="https://api.openai.com/v1",
        )
        st.session_state.api_model = st.text_input(
            "Model name",
            value=st.session_state.api_model,
            placeholder="gemini-1.5-flash",
        )
        st.caption("Gemini model options: gemini-1.5-flash (fast, free) · gemini-1.5-pro (better)")

    sync_agent_settings(agent)

    if st.button("New chat", use_container_width=True):
        st.session_state.chat_history = [WELCOME_MSG]
        st.rerun()


# ── Main chat ─────────────────────────────────────────────────
st.markdown(
    """
    <div class="main-head">
        <h1>Chat with your agent</h1>
        <p>Simple questions about farming — answers from guides, models, and AI.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

quick_prompt = None
starters = [
    ("Crops", "What crops are good for kharif in Maharashtra?"),
    ("Soil", "How can I improve my soil?"),
    ("Prices", "When should I sell at the mandi?"),
    ("Pests", "How do I treat common crop pests?"),
]
cols = st.columns(4)
for i, (label, prompt) in enumerate(starters):
    with cols[i]:
        if st.button(label, key=f"q_{i}", use_container_width=True):
            quick_prompt = prompt

for msg in st.session_state.chat_history:
    avatar = "🌾" if msg["role"] == "assistant" else "👨‍🌾"
    with st.chat_message(msg["role"], avatar=avatar):
        st.write(msg["text"])
        if msg["role"] == "assistant" and msg.get("engine"):
            st.caption(f"Answered with: {msg['engine']}")
        if msg["role"] == "assistant" and msg.get("tools_used"):
            tags = " ".join(
                f'<span class="tag">{t}</span>' for t in msg["tools_used"]
            )
            st.markdown(tags, unsafe_allow_html=True)

user_prompt = quick_prompt or st.chat_input("Type your question…")

if user_prompt:
    sync_agent_settings(agent)
    st.session_state.chat_history.append({"role": "user", "text": user_prompt})

    with st.spinner("Thinking…"):
        tools_used = agent.get_tools_used(user_prompt)
        reply = agent.answer(user_prompt)

    st.session_state.chat_history.append({
        "role": "assistant",
        "text": reply,
        "tools_used": tools_used,
        "engine": engine_label(agent),
    })
    st.rerun()
